library(testthat)

test_that("Fishy Business of Ireland Works",{


     data("FishLocation")
     data("FishPrice")
  expect_that(FishPortPrice(FishPrice, FishLocation),is_true())

# tests that the price data file contains one or more value in the dataset
    expect_gte(FishTypeTot(FishPrice),0)

})
